# Zutrittscheck OCR-Prototyp

## Testen
1. Lade `index.html` in dein GitHub-Repository `zutrittscheck-test` hoch und ersetze damit die bisherige `index.html`.
2. Öffne die GitHub-Pages-Seite erneut.
3. Tippe auf „Künstliche Beispieldaten laden“.
4. Für den OCR-Test nur ein selbst erstelltes Testblatt mit erfundenen Angaben fotografieren.

## Wichtig
- Nur Prototyp, nicht für den echten Anlass einsetzen.
- Keine echten Ausweise oder Gästelisten auf die öffentliche GitHub-Seite hochladen.
- Die Gästeliste wird vom Browser eingelesen und nicht vom Code an GitHub hochgeladen. XLSX-Unterstützung und OCR-Bibliothek werden beim Bedarf von einem CDN geladen; Bild und Abgleichsdaten werden nicht an diesen CDN übertragen.
- OCR ist nicht automatisch zuverlässig. Derzeit wird erkannter Text angezeigt, aber Vorname/Nachname/Geburtsdatum werden nicht automatisch sicher zugeordnet. Angaben manuell prüfen und eingeben.
- Noch keine geräteübergreifende Synchronisierung, Protokollierung oder robuste Unterstützung aller Excel-Formate.
